
  # Manager and Volunteer UI

  This is a code bundle for Manager and Volunteer UI. The original project is available at https://www.figma.com/design/ySyQxIbc6iXvCqua6gzJM3/Manager-and-Volunteer-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  